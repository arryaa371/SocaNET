export function canAdvance(score: number): boolean {
  return score >= 2;
}
