# Rigor as a Baseline

This is not a productivity app.

This is a discipline-enforcing epistemic environment.

Productivity without rigor is motion without direction.
